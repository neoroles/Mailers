<?php
error_reporting(0);
date_default_timezone_set("Asia/Jakarta");
// Import PHPMailer classes into the global namespace
// These must be at the top of your script, not inside a function
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

//Load composer's autoloader
require 'phpmailer_load/autoload.php';
$setting      	= new setting;
$loader 	   	= new loader;

class loader{
	public function getconf(){
	require('config.php');
		$data = array(
			'multiple' => array(
				'host' 			=> $hostname,
				'username' 		=> $username,
				'password'		=> $password,
				'secure'		=> $secure,
				'port'			=> $port
			),
			'sensoremail'	=> $sensoremail,
			'frommail'		=> $frommail,
			'fromname'		=> $fromname,
			'priority'		=> $priority,
			'bmheader'		=> $bmheader,
			'subject'		=> $subject,
			'letter'		=> $letter,
			'attachment'	=> $attachment,
			'language'		=> $language,
			'duplicate'		=> $duplicate,
			'remove'		=> $removeaftersend,
			'emaillist'		=> $emaillist,
			'mode'			=> $mode,
			'delay'			=> array(
				'email'			=> $email,
				'time'			=> $delay
			)
		);
		return $data;
	}
}
class setting{
	public $string				= "abdefghijklmnopqrtuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
	public $number				= "0123456789";

	public function duplicate($file, $duplicate = 1){
		$data = file($file);
		if ($duplicate == 1) {
			$result = file_put_contents($file, implode(array_unique($data)));
		}else{
			$result = $file;
		}
	}

	public function getMailist($file, $duplicate = false){
		$file = file_get_contents($file);

		if($file == ""){
			echo "\nEmailist not found.";
			exit;
		}

		if (strtoupper(substr(PHP_OS, 0, 3)) === "WIN") {
			$file = explode("\r\n", $file);
		}else {
			$file = explode("\n", $file);
		}

		if($duplicate == 1){
			$file = array_unique($file);
		}elseif($duplicate == 0){
			$file = $file;
		}

		return array(
			'total' => count($file),
			'list'  => $file,
		);
	}

	public function array_random(array $array) {
		return $array[array_rand($array, 1)];
	}

	public function random_country(){
		$randcon = $this->array_random(
			array(
				'Uganda',
				'Príncipe',
				'Puerto Rico',
				'Solomon Islands',
				'Barbados',
				'Mali',
				'Tobago',
				'Tanzania',
				'Herzegovina',
				'Caribbean Netherlands',
				'Italy',
				'Wallis',
				'Rwanda',
				'Curaçao',
				'Niger',
				'Guinea',
				'Brunei',
				'St. Lucia',
				'Romania',
				'Nauru',
				'Guam',
				'Sri Lanka',
				'Oman',
				'Bhutan',
				'Afghanistan',
				'Qatar',
				'Haiti',
				'United Kingdom',
				'Botswana',
				'Miquelon',
				'South Georgia',
				'North Korea',
				'Guinea-Bissau',
				'Mayotte',
				'Yemen',
				'Jamaica',
				'Cape Verde',
				'Antarctica',
				'Isle of Man',
				'Spain',
				'Equatorial Guinea',
				'Guadeloupe',
				'Kiribati',
				'Ethiopia',
				'British Virgin Islands',
				'Laos',
				'Turks',
				'Chad',
				'Uzbekistan',
				'Morocco',
				'Namibia',
				'Åland Islands',
				'Uruguay',
				'Burundi',
				'Peru',
				'Sierra Leone',
				'Montserrat',
				'Myanmar (Burma)',
				'Russia',
				'Svalbard',
				'St. Kitts',
				'Monaco',
				'Argentina',
				'Albania',
				'Jordan',
				'Singapore',
				'Bosnia',
				'Christmas Island',
				'Brazil',
				'Pitcairn Islands',
				'Colombia',
				'Andorra',
				'Czech Republic',
				'Tonga',
				'St. Martin',
				'Netherlands Antilles',
				'Cuba',
				'Portugal',
				'Pakistan',
				'São Tomé',
				'Western Sahara',
				'Mozambique',
				'Georgia',
				'Costa Rica',
				'Algeria',
				'Vietnam',
				'St. Vincent','Grenadines',
				'Congo - Kinshasa',
				'Iraq',
				'Indonesia',
				'Switzerland',
				'Canada',
				'Niue',
				'Gibraltar',
				'Turkmenistan',
				'Sudan',
				'China',
				'Kuwait',
				'Guatemala',
				'Norfolk Island',
				'Estonia',
				'Moldova',
				'Greece',
				'South Sudan',
				'Malawi',
				'Palau',
				'Gambia',
				'Bulgaria',
				'Libya',
				'Aruba',
				'Syria',
				'Montenegro',
				'Panama',
				'Marshall Islands',
				'Central African Republic',
				'Bolivia',
				'Senegal',
				'New Zealand',
				'Poland',
				'Timor-Leste',
				'Greenland',
				'Macau SAR China',
				'Nigeria',
				'Austria',
				'Seychelles',
				'Micronesia',
				'Liechtenstein',
				'Burkina Faso',
				'India',
				'Papua New Guinea',
				'Cook Islands',
				'Japan',
				'Swaziland',
				'Guernsey',
				'France',
				'Philippines',
				'St. Barthélemy',
				'Cameroon',
				'St. Helena',
				'Tokelau',
				'Chile',
				'Malta',
				'Ireland',
				'Iran',
				'Zambia',
				'Zimbabwe',
				'Mexico',
				'Jersey',
				'Denmark',
				'Croatia',
				'San Marino',
				'Sweden',
				'Guyana',
				'Lithuania',
				'Kyrgyzstan',
				'Hungary',
				'Paraguay',
				'Ghana',
				'Trinidad',
				'Nevis',
				'Somalia',
				'American Samoa',
				'Dominica',
				'U.S. Virgin Islands',
				'Dominican Republic',
				'Belgium',
				'Ecuador',
				'New Caledonia',
				'Luxembourg',
				'Iceland',
				'Mongolia',
				'Belarus',
				'Grenada',
				'Tuvalu',
				'Faroe Islands',
				'Palestinian Territories',
				'United States',
				'Malaysia',
				'Lebanon',
				'Slovakia',
				'Barbuda',
				'Kenya',
				'South Africa',
				'Maldives',
				'Tunisia',
				'Ukraine',
				'Armenia',
				'South Sandwich Islands',
				'Kazakhstan',
				'Côte d’Ivoire',
				'Egypt',
				'Thailand',
				'Israel',
				'Caicos Islands',
				'Cambodia',
				'Venezuela',
				'Vanuatu',
				'Tajikistan',
				'Liberia',
				'Lesotho',
				'Netherlands',
				'Fiji',
				'Germany',
				'El Salvador',
				'Bahrain',
				'Réunion',
				'Turkey',
				'Gabon',
				'Australia',
				'Finland',
				'Eritrea',
				'Martinique',
				'Norway',
				'Mauritania',
				'Saudi Arabia',
				'Futuna',
				'Northern Mariana Islands',
				'St. Pierre',
				'Togo',
				'Angola',
				'Vatican City',
				'Azerbaijan',
				'Jan Mayen',
				'Macedonia',
				'Falkland Islands',
				'Honduras',
				'Congo - Brazzaville',
				'Kosovo',
				'Hong Kong SAR China',
				'Samoa',
				'Antigua',
				'Mauritius',
				'Nicaragua',
				'Slovenia',
				'Comoros',
				'Sint Maarten',
				'Bangladesh',
				'Madagascar',
				'French Guiana',
				'Anguilla',
				'Serbia',
				'Nepal',
				'Bahamas',
				'Djibouti',
				'Benin',
				'Cocos (Keeling) Islands',
				'Latvia',
				'Cyprus',
				'United Arab Emirates',
				'French Polynesia',
				'Taiwan',
				'Cayman Islands',
				'Bermuda',
				'Suriname',
				'South Korea',
				'Belize'
			)
);
$random_country = rand(0,13);
switch($random_country)
{
	case 1:
	return $randcon;
	break;
	case 2:
	return $randcon;
	break;
	case 3:
	return $randcon;
	break;
	case 4:
	return $randcon;
	break;
	case 5:
	return $randcon;
	break;
	case 6:
	return $randcon;
	break;
	case 7:
	return $randcon;
	break;
	case 8:
	return $randcon;
	break;
	case 9:
	return $randcon;
	break;
	case 10:
	return $randcon;
	break;
	case 11:
	return $randcon;
	break;
	case 12:
	return $randcon;
	break;
	case 13:
	return $randcon;
	break;
	default:
	return $randcon;
	break;
}
}
public function random_device(){
        $randdev = $this->array_random(
            array(
                'Oppo F1',
                'Oppo F1s',
                'Oppo A37f',
                'Oppo A15',
                'Oppo A11K',
                'Oppo Reno4 F',
                'Oppo A53',
                'Oppo A92',
                'Vivo Y1s',
                'Vivo Y51',
                'Vivo Y12s',
                'Vivo Y20s',
                'Vivo V20',
                'Vivo V20 SE',
                'Vivo X50 Pro',
                'iPhone 5',
                'iPhone 5s',
                'iPhone 6',
                'iPhone 6s',
                'Redmi Note 9 Pro',
                'Redmi Note 9',
                'Poco M3',
                'Redmo K30s',
                'Xiaomi Mi K30s',
                'Xiaomi Mi 10T',
                'Xiaomi Mi 10T Lite',
                'Realme Narzo 20 Pro',
                'Realme Narzo 20 Pro',
                'Realme C17',
                'Realme 7',
                'Realme 7i',
                'Realme 7 Pro',
                'Samsung Galaxy A11',
                'Samsung Galaxy A21S',
                'Samsung Galaxy A71',
                'Samsung Galaxy AM11',
                'Samsung Galaxy M21',
                'Samsung Galaxy Z',
                'Samsung Galaxy S20',
                'Smartfren Andromax A2',
                'Smartfren Andromax B SE',
                'Smartfren Andromax L',
                'Smartfren Andromax R',
                'Asus ZenFone Max Pro M2',
                'Asus ZenFone Max M2',
                'Asus ZenFone 5Z',
                'Asus Zenfone 5',
                'Asus ZenFone Live L1',
                'Asus ZenFone Max Plus',
                'Asus ZenFone Max Pro',
                'Advan G9 Pro',
                'Advan Nasa Plus',
                'Advan G5',
                'Advan G3 Pro',
                'Advan G9',
                'Motorola Moto M',
                'Motorola Moto C',
                'Motorola Moto E4',
                'Motorola Moto G5S',
                'Motorola RAZR V3',
                'Motorola Z2 Play'
            )
);

$random_device = rand(0,13);
switch($random_device)
{
    case 1:
    return $randdev;
    break;
    case 2:
    return $randdev;
    break;
    case 3:
    return $randdev;
    break;
    case 4:
    return $randdev;
    break;
    case 5:
    return $randdev;
    break;
    case 6:
    return $randdev;
    break;
    case 7:
    return $randdev;
    break;
    case 8:
    return $randdev;
    break;
    case 9:
    return $randdev;
    break;
    case 10:
    return $randdev;
    break;
    case 11:
    return $randdev;
    break;
    case 12:
    return $randdev;
    break;
    case 13:
    return $randdev;
    break;
    default:
    return $randdev;
    break;
}
}
public function random_price(){
    $randprice = $this->array_random(
                array(
                'US$140',
                'US$141',
                'US$142',
                'US$143',
                'US$144',
                'US$145',
                'US$156',
                'US$156',
                'US$157',
                'US$158',
                'US$159',
                'US$150',
                'US$151',
                'US$152',
                'US$153',
                'US$154',
                'US$155',
                'US$156',
                'US$157',
                'US$158',
                'US$159',
                'US$160',
                'US$161',
                'US$162',
                'US$163',
                'US$164',
                'US$165',
                'US$166',
                'US$167',
                'US$168',
                'US$169',
                'US$170',
                'US$171',
                'US$172',
                'US$173',
                'US$174',
                'US$175',
                'US$176',
                'US$177',
                'US$178',
                'US$179',
                'US$180',
            )
);

$random_price = rand(0,13);
switch($random_price)
{
    case 1:
    return $randprice;
    break;
    case 2:
    return $randprice;
    break;
    case 3:
    return $randprice;
    break;
    case 4:
    return $randprice;
    break;
    case 5:
    return $randprice;
    break;
    case 6:
    return $randprice;
    break;
    case 7:
    return $randprice;
    break;
    case 8:
    return $randprice;
    break;
    case 9:
    return $randprice;
    break;
    case 10:
    return $randprice;
    break;
    case 11:
    return $randprice;
    break;
    case 12:
    return $randprice;
    break;
    case 13:
    return $randprice;
    break;
    default:
    return $randprice;
    break;
}
}

public function random_ip(){
	$randIP= ''.mt_rand(0,255).'.'.mt_rand(0,255).'.'.mt_rand(0,255).'.'.mt_rand(0,255);
	$random_IP = rand(0,13);
	switch($random_IP)
	{
		case 1:
		return $randIP;
		break;
		case 2:
		return $randIP;
		break;
		case 3:
		return $randIP;
		break;
		case 4:
		return $randIP;
		break;
		case 5:
		return $randIP;
		break;
		case 6:
		return $randIP;
		break;
		case 7:
		return $randIP;
		break;
		case 8:
		return $randIP;
		break;
		case 9:
		return $randIP;
		break;
		case 10:
		return $randIP;
		break;
		case 11:
		return $randIP;
		break;
		case 12:
		return $randIP;
		break;
		case 13:
		return $randIP;
		break;
		default:
		return $randIP;
		break;
	}
}

public function random_browser(){
	$arr 	= $this->array_random(
		array('i686', 'x86_64')
	);
	$array 	= $this->array_random(
		array(
			'Mozilla/5.0 (Windows NT '.rand(5,6).'.'.rand(0,1).') Chrome'.rand(13, 15).'.0.'.rand(800, 899).'.0',
			'Mozilla/5.0 (X11; Linux '.$arr.') Chrome'.rand(13, 15).'.0.'.rand(800, 899).'.0',
			'Mozilla/5.0 (Macintosh; U; '.$arr.') Chrome'.rand(13, 15).'.0.'.rand(800, 899).'.0',
			'Mozilla/5.0 (Windows NT '.rand(5,6).'.'.rand(0,1).') Firefox/'.rand(5, 7).'.0',
			'Mozilla/5.0 (X11; Linux '.$arr.') Firefox/' .rand(5, 7).'.0',
			'Mozilla/5.0 (Macintosh; U; '.$arr.') Firefox/' .rand(5, 7).'.0',
			'Mozilla/5.0 (Windows NT '.rand(5,6).'.'.rand(0,1).') Firefox/'.rand(5, 7).'.0.1',
			'Mozilla/5.0 (X11; Linux '.$arr.') Firefox/'.rand(5, 7).'.0.1',
			'Mozilla/5.0 (Macintosh; U; '.$arr.') Firefox/'.rand(5, 7).'.0.1',
			'Mozilla/5.0 (Windows NT '.rand(5,6).'.'.rand(0,1).') Firefox/3.6.'.rand(1, 20),
			'Mozilla/5.0 (X11; Linux '.$arr.') Firefox/3.6.'.rand(1, 20),
			'Mozilla/5.0 (Macintosh; U; '.$arr.') Firefox/3.6.'.rand(1, 20),
			'Mozilla/5.0 (Windows NT '.rand(5,6).'.'.rand(0,1).') Firefox/3.8',
			'Mozilla/5.0 (X11; Linux '.$arr.') Firefox/3.8',
			'Mozilla/5.0 (Macintosh; U; '.$arr.') Firefox/3.8'
		)
	);
	return $array;
}

public function random_string($lenght){
	$variable = $this->string;
	$string   = '';
	for ($i = 0; $i < $lenght; $i++)
	{
		$post   = rand(0, strlen($variable)-1);
		$string .= $variable{$post};
	}
	return $string;
}

function random_string_lowercase($length) {
	$characters = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
	$charactersLength = strlen($characters);
	$randomString = '';
	for ($i = 0; $i < $length; $i++) {
		$randomString .= $characters[rand(0, $charactersLength - 1)];
	}
	return strtolower($randomString);
}

public function random_number($lenght){
	$variable = $this->number;
	$string   = '';
	for ($i = 0; $i < $lenght; $i++){
		$post   = rand(0, strlen($variable)-1);
		$string .= $variable{$post};
	}
	return $string;
}

public function getDate(){
	$year 		= date(", Y");
	$month 		= date("M");
	$day 		= (date("d"));
	$date 	= ( $day." ".$month.$year);
	return $date;
}

public function getLetter($getLetter = null, $letter = null){
	$letter = file_get_contents($letter);

	if($letter == ""){
		echo "\nLetter not found.";
		exit;
	}else{
		foreach ($getLetter as $key => $value){
			$letter = str_replace($key, $value, $letter);
		}
	}

	return $letter;
}

public function getFrommailSetting($frommail = null, $custom = null){
	$custom = $custom;

	if($custom == ""){
		echo "\nMail not found.";
		exit;
	}else{
		foreach ($frommail as $key => $value){
			$custom = str_replace($key, $value, $custom);
		}
	}

	return $custom;
}

public function getFromnameSetting($fromname = null, $custom = null){
	$custom = $custom;

	if($custom == ""){
		echo "\nName not found.";
		exit;
	}else{
		foreach ($fromname as $key => $value){
			$custom = str_replace($key, $value, $custom);
		}
	}

	return $custom;
}

public function getSubjectSetting($subject = null, $custom = null){
	$custom = $custom;

	if($custom == ""){
		echo "\Subject not found.";
		exit;
	}else{
		foreach ($subject as $key => $value){
			$custom = str_replace($key, $value, $custom);
		}
	}

	return $custom;
}

}

echo chr(27).chr(91).'H'.chr(27).chr(91).'J';
echo "\033[1;36m██╗  ██╗███╗   ███╗ █████╗ ██████╗ ██╗   ██╗███████╗██╗\n";
echo "\033[1;36m╚██╗██╔╝████╗ ████║██╔══██╗██╔══██╗██║   ██║██╔════╝██║\033[0m \033[0;101mBY xMarval_support\033[0m\n";
echo "\033[1;36m ╚███╔╝ ██╔████╔██║███████║██████╔╝██║   ██║█████╗  ██║ \033[0m \033[0;101mVERSION : V2.0  \033[0m\n";
echo "\033[1;36m ██╔██╗ ██║╚██╔╝██║██╔══██║██╔══██╗╚██╗ ██╔╝██╔══╝  ██║  \033[0m \n";
echo "\033[1;36m██╔╝ ██╗██║ ╚═╝ ██║██║  ██║██║  ██║ ╚████╔╝ ███████╗███████╗\033[0m\n";
echo "\033[1;36m╚═╝  ╚═╝╚═╝     ╚═╝╚═╝  ╚═╝╚═╝  ╚═╝  ╚═══╝  ╚══════╝╚══════╝\033[0m\n";
echo "\t\t\033[0;101mCRACKED BY: @f4c3r100 \033[0m\n\n";
echo "\n";
			try {
				$account 		= $loader->getconf();
				if ($account['duplicate'] == 1) {
					$setting->duplicate('mailist/'.$account['emaillist'].'', $account['duplicate']);
					echo "\033[43m        REMOVING DUPLICATE           \033[0m\n";
					sleep(3);
					echo "\n";
					echo "\033[42m         SUCCESS REMOVING            \033[0m\n";
				}
				$mailist 		= $setting->getMailist('mailist/'.$account['emaillist'].'', $account['duplicate']);
				$emaillist 		= $mailist['list'];
				$sended = 1;
				$delay = 0;
				$start = microtime(true);
				$end = 0;
				$result = count($emaillist);

				foreach ($emaillist as $key => $email) {
					$randstring2 	= $setting->random_string_lowercase(2);
					$randstring3 	= $setting->random_string_lowercase(3);
					$randstring4 	= $setting->random_string_lowercase(4);
					$randstring5 	= $setting->random_string_lowercase(5);
					$randnumber2 	= $setting->random_number(2);
					$randnumber3 	= $setting->random_number(3);
					$randnumber4 	= $setting->random_number(4);
					$randnumber5 	= $setting->random_number(5);
					$date 			= $setting->getDate();
					$randcountry = $setting->random_country();
					$randip = $setting->random_IP();
					$randdev = $setting->random_device();
					$randprice = $setting->random_price();

					$elapsed = $end  - $start;
					$end = microtime(true);

					$email  = trim(strtolower($email));
					$total 	= count($account['multiple']['username']) - 1;
					$mix 	= rand(0, $total);

					$total2 = count($account['link']) - 1;
					$mix2 	= rand(0, $total2);

					if ($account['sensoremail'] == 1) {
						$emailsensored = str_replace(array('a', 'i', 'u', 'e', 'o'), array('*', '*', '*', '*', '*'), $email);
					}else{
						$emailsensored = $email;
					}

					$feature = array(
						'##email##'   => $emailsensored,
						'##country##' => $randcountry,
						'##ip##'      => $randip,
						'##device##'  => $randdev,
						'##price##'	  => $randprice,
						'##num2##'  => $randnumber2,
						'##num3##'  => $randnumber3,
						'##num4##'  => $randnumber4,
						'##num5##'  => $randnumber5,
						'##string2##'  => $randstring2,
						'##string3##'  => $randstring3,
						'##string4##'  => $randstring4,
						'##string5##'  => $randstring5,
						'##date##'    => $setting->getDate(),
						'##browser##' => $setting->random_browser(),
						'##link##' 	=> $account['link'][$mix2]
					);

					$mail = new PHPMailer(true);                          // Passing `true` enables exceptions
					$mail->isSMTP();                                      // Set mailer to use SMTP
					$mail->Host = $account['multiple']['host'][$mix];  // Specify main and backup SMTP servers
					$mail->SMTPAuth = true;                               // Enable SMTP authentication
					$mail->Username = $account['multiple']['username'][$mix];                 // SMTP username
					$mail->Password = $account['multiple']['password'][$mix];                           // SMTP password
					$mail->SMTPSecure = $account['multiple']['secure'][$mix];                            // Enable TLS encryption, `ssl` also accepted
					$mail->Port = $account['multiple']['port'][$mix];                                    // TCP port to connect to
					$mail->SMTPOptions = array(
						'ssl' => array(
							'verify_peer'  => false,
							'verify_peer_name'  => false,
							'allow_self_signed' => true
						)
					);

					//Recipients
						$myfeature = array(
						'##num2##'  => $randnumber2,
						'##num3##'  => $randnumber3,
						'##num4##'  => $randnumber4,
						'##num5##'  => $randnumber5,
						'##string2##'  => $randstring2,
						'##string3##'  => $randstring3,
						'##string4##'  => $randstring4,
						'##string5##'  => $randstring5
						);
						$custom = $account['frommail'];
						$frommail = $setting->getFrommailSetting($myfeature, $custom);

						$myfeature = array(
						'##num2##'  => $randnumber2,
						'##num3##'  => $randnumber3,
						'##num4##'  => $randnumber4,
						'##num5##'  => $randnumber5,
						'##string2##'  => $randstring2,
						'##string3##'  => $randstring3,
						'##string4##'  => $randstring4,
						'##string5##'  => $randstring5
						);
						$custom = $account['fromname'];
						$fromname = $setting->getFromnameSetting($myfeature, $custom);

					$mail->setFrom($frommail, $fromname);
					if ($account['mode'] == 0) {
					$mail->addAddress($email);
					}else
					if ($account['mode'] == 1) {
					$mail->addBCC($email);
					}
					if ($account['attachment'] != '') {
						$mail->AddAttachment('attachment/'. $account['attachment']);
					}

					//Content
					$mail->isHTML(true);                                  // Set email format to HTML

					$mail->setLanguage($account['language']);
					$mail->Priority 	= $account['priority'];
					if ($account['bmheader'] == 1) {
						if ($account['priority'] == 1) {
							$mail->XMailer = "Gibberish";
							$mail->AddCustomHeader("Importance: High");
							$mail->AddCustomHeader("X-MSMail-Priority: High");	// Not sure if Priority will also set the Importance header:
						}
					}elseif ($account['bmheader'] == 0) {

					}else{

					}
					$mail->Encoding         = 'base64';
					$mail->CharSet          = 'UTF-8';
					$mail->ContentType      = 'plain/text';
					$mail->MessageDate      = $setting->getDate();
					if ($account['subject'] != 'zrandsubject') {
						$myfeature = array(
						'##email##'   => $emailsensored,
						'##country##' => $randcountry,
						'##ip##'      => $randip,
						'##num2##'  => $randnumber2,
						'##num3##'  => $randnumber3,
						'##num4##'  => $randnumber4,
						'##num5##'  => $randnumber5,
						'##string2##'  => $randstring2,
						'##string3##'  => $randstring3,
						'##string4##'  => $randstring4,
						'##string5##'  => $randstring5,
						'##device##'  => $randdev,
						'##price##'	  => $randprice,
							'##date##'    => $setting->getDate(),
							'##browser##' => $setting->random_browser()
						);

						$custom = $account['subject'];
						$subject = $setting->getSubjectSetting($myfeature, $custom);
					}else{

						$subject = $randsubject;
					}
					$mail->Subject = $subject;
					$mail->msgHTML($setting->getLetter($feature, 'letter/'.$account['letter'].''));


					if ($mail->send()) {
						$info = 'Has send';
					}else{
						$info = 'Fail send';
					}

					$hours = number_format($elapsed + $account['delay']['time'], 0, '.', '');
					$minutes = $hours % 3600;
					$second = $minutes % 3600;
						if ($delay === $account['delay']['email']){
							echo "\n";
							echo "\033[43m    WAITING ".$account['delay']['time']." SECOND ".number_format($minutes / 60, 0)." MINUTES     \033[0m";
							echo "\n";
							echo "\n";
							sleep($account['delay']['time']);
								echo "\033[1;31m[\033[0m\033[1;36m+\033[0m\033[1;31m]\033[0m ";
								echo "\033[1;31m[\033[0m";
								echo "\033[1;32m";
								echo ''.date('H:m:s').'';
								echo "\033[0m" ;
								echo "\033[1;31m]\033[0m ";
								echo "\033[1;31m[\033[0m";
								echo "\033[1;36m";
								echo ''.$email.'';
								echo "\033[0m" ;
								echo "\033[1;31m]\033[0m ";
								echo "\033[45m";
								echo '[ '.$sended.' ] / '.$mailist['total'].'';
								echo "\033[0m";
							$delay = 0;
						}
						else{
								echo "\033[1;31m[\033[0m\033[1;36m+\033[0m\033[1;31m]\033[0m ";
								echo "\033[1;31m[\033[0m";
								echo "\033[1;32m";
								echo ''.date('H:m:s').'';
								echo "\033[0m" ;
								echo "\033[1;31m]\033[0m ";
								echo "\033[1;31m[\033[0m";
								echo "\033[1;36m";
								echo ''.$email.'';
								echo "\033[0m" ;
								echo "\033[1;31m]\033[0m ";
								echo "\033[45m";
								echo '[ '.$sended.' ] / '.$mailist['total'].'';
								echo "\033[0m";
						}
						echo "\n";
					// }
					if ($account['remove'] == 1) {
						$file = 'mailist/'. $account['emaillist'];
						$array = file($file);
						unset($array[0]);
						$fp = fopen($file, 'w+');

						foreach($array as $line){
							fwrite($fp,$line);
						}
						fclose($fp);
					}


					$sended++;
					$delay++;
				}
				echo "\n";
				echo "\n";
				echo "\033[32m\t\t        SENT SUCCESS => \033[34m[\033[31m$email\033[34m]\033[0m\n\n\n";
			} catch (Exception $e) {
				echo "\033[32m\t\t        SENT SUCCESS => \033[34m[\033[31m$email\033[34m]\033[0m\n\n\n";
			} catch (Exception $e) {
				echo "\033[0;101mBM7SENDER Error: " . $mail->ErrorInfo;
				echo "\033[0m" ;
			}
?>
