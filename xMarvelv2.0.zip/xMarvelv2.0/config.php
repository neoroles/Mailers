<?php

/*
██╗  ██╗███╗   ███╗ █████╗ ██████╗ ██╗   ██╗███████╗██╗
╚██╗██╔╝████╗ ████║██╔══██╗██╔══██╗██║   ██║██╔════╝██║
 ╚███╔╝ ██╔████╔██║███████║██████╔╝██║   ██║█████╗  ██║
 ██╔██╗ ██║╚██╔╝██║██╔══██║██╔══██╗╚██╗ ██╔╝██╔══╝  ██║
██╔╝ ██╗██║ ╚═╝ ██║██║  ██║██║  ██║ ╚████╔╝ ███████╗███████╗
    ╚═╝  ╚═╝╚═╝ ╚═╝╚═╝  ╚═╝╚═╝  ╚═╝  ╚═══╝  ╚══════╝╚══════╝
xMarvel Sender v2.0 [UPDATE]
*/
#SMTP SETUP

#smtp.googlemail.com|465|zinzodeli@gmail.com|Zinzodeli123$$

$hostname[]		= 'smtp_host';
$username[] 	= 'smtp_user';
$password[] 	= 'smtp_pass';
$secure[] 		= 'tls'; ## port 465 = SSL | port 587 = TLS
$port[] 		= '587';

#EMAIL SETUP
$frommail 		= ''; # from mail => same as username
$fromname 		= 'Support';
$subject 		= 'Your id Disabled !';

#LETTER SETUP
$letter 		= 'letter.html';
$attachment 	= '';
$language 		= 'us';
$emaillist 		= 'list.txt';

#FEATURES
$bmheader 		 = 1;  // xMarvel HEADER , 0 = OFF | 1 = ON ( USE 1 RECOMMENDED )
$priority 		 = 1;  // 0 = NORMAL | 1 = HIGH
$mode			 = 1;  // 0 = TO  | 1 = BCC ( USE 1 RECOMMENDED )
$sensoremail 	 = 0;  // 0 = OFF | 1 = ON ( USE 0 RECOMMENDED )
$duplicate 		 = 0;  // 0 = OFF | 1 = ON
$removeaftersend = 0;  // 0 = OFF | 1 = ON
$delay 			 = 3;  // DELAY = $DELAY SECOND/$EMAIL ( USE 3 RECOMMENDED )
$email 			 = 30;  // DELAY FOR MUCH EMAIL ( USE 30 RECOMMENDED )

?>
